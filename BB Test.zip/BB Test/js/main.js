/**
 * Bunneis — Main Interactions
 * Scroll reveal animations, filter buttons, smooth UX.
 */
(function () {
  /* ===== Scroll Reveal ===== */
  function initReveal() {
    const items = document.querySelectorAll('.reveal');
    if (!items.length) return;
    const obs = new IntersectionObserver((entries) => {
      entries.forEach(e => { if (e.isIntersecting) { e.target.classList.add('visible'); obs.unobserve(e.target); } });
    }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });
    items.forEach(el => obs.observe(el));
  }

  /* ===== Filter Buttons ===== */
  function initFilters() {
    const bar = document.querySelector('.filter-bar');
    if (!bar) return;
    bar.addEventListener('click', e => {
      const btn = e.target.closest('.filter-btn');
      if (!btn) return;
      bar.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const cat = btn.dataset.filter;
      document.querySelectorAll('[data-category]').forEach(card => {
        const show = cat === 'all' || card.dataset.category === cat;
        card.style.display = show ? '' : 'none';
        if (show) { card.classList.remove('visible'); requestAnimationFrame(() => card.classList.add('visible')); }
      });
    });
  }

  /* ===== Particle Generator (Hero) ===== */
  function initParticles() {
    const container = document.querySelector('.hero-particles');
    if (!container) return;
    for (let i = 0; i < 20; i++) {
      const p = document.createElement('div');
      p.className = 'hero-particle';
      p.style.left = Math.random() * 100 + '%';
      p.style.top = Math.random() * 100 + '%';
      p.style.animationDelay = Math.random() * 8 + 's';
      p.style.animationDuration = (6 + Math.random() * 6) + 's';
      p.style.width = p.style.height = (3 + Math.random() * 6) + 'px';
      container.appendChild(p);
    }
  }

  /* ===== Init ===== */
  function init() {
    initReveal();
    initFilters();
    initParticles();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
