/**
 * Bunneis — Component Loader
 * Loads header.html & footer.html into placeholders, sets active nav link.
 */
(function () {
  const parts = [
    { id: 'header-placeholder', file: 'components/header.html' },
    { id: 'footer-placeholder', file: 'components/footer.html' }
  ];

  function getPage() {
    const path = location.pathname.split('/').pop().replace('.html', '') || 'index';
    return path;
  }

  function setActive() {
    const page = getPage();
    document.querySelectorAll('.nav-link').forEach(link => {
      link.classList.toggle('active', link.dataset.page === page);
    });
  }

  function initMobileMenu() {
    const toggle = document.getElementById('mobile-toggle');
    const nav = document.getElementById('nav-list');
    if (!toggle || !nav) return;
    toggle.addEventListener('click', () => {
      toggle.classList.toggle('active');
      nav.classList.toggle('open');
    });
    nav.querySelectorAll('.nav-link').forEach(link => {
      link.addEventListener('click', () => {
        toggle.classList.remove('active');
        nav.classList.remove('open');
      });
    });
  }

  function initHeaderScroll() {
    const header = document.getElementById('main-header');
    if (!header) return;
    window.addEventListener('scroll', () => {
      header.classList.toggle('scrolled', window.scrollY > 50);
    }, { passive: true });
  }

  async function load(part) {
    const el = document.getElementById(part.id);
    if (!el) return;
    try {
      const res = await fetch(part.file);
      if (!res.ok) throw new Error(res.status);
      el.innerHTML = await res.text();
    } catch (e) {
      console.warn(`Failed to load ${part.file}:`, e);
    }
  }

  async function init() {
    await Promise.all(parts.map(load));
    setActive();
    initMobileMenu();
    initHeaderScroll();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
