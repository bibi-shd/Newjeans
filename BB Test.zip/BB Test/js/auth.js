/**
 * Bunneis — Google Sign-In (Auth Module)
 * Uses Google Identity Services (GIS) for sign-in with Google.
 * Falls back to a demo mode when running locally without a Client ID.
 */
(function () {
  const CLIENT_ID = ''; // Set your Google OAuth Client ID here

  /* ===== State ===== */
  let currentUser = JSON.parse(localStorage.getItem('bunneis_user') || 'null');

  /* ===== Render Auth UI ===== */
  function renderAuthUI() {
    const container = document.getElementById('auth-container');
    if (!container) return;

    if (currentUser) {
      container.innerHTML = `
        <div class="auth-profile" id="auth-profile">
          <img src="${currentUser.picture}" alt="${currentUser.name}" class="auth-avatar" referrerpolicy="no-referrer">
          <div class="auth-dropdown" id="auth-dropdown">
            <div class="auth-dropdown-header">
              <img src="${currentUser.picture}" alt="" class="auth-dropdown-avatar" referrerpolicy="no-referrer">
              <div>
                <div class="auth-dropdown-name">${currentUser.name}</div>
                <div class="auth-dropdown-email">${currentUser.email}</div>
              </div>
            </div>
            <div class="auth-dropdown-divider"></div>
            <button class="auth-dropdown-item" id="btn-signout">
              <span>🚪</span> ออกจากระบบ
            </button>
          </div>
        </div>
      `;
      // Toggle dropdown
      const profile = document.getElementById('auth-profile');
      const dropdown = document.getElementById('auth-dropdown');
      profile.addEventListener('click', (e) => {
        e.stopPropagation();
        dropdown.classList.toggle('show');
      });
      document.addEventListener('click', () => dropdown.classList.remove('show'));
      // Sign out
      document.getElementById('btn-signout').addEventListener('click', signOut);
    } else {
      container.innerHTML = `
        <button class="auth-signin-btn" id="btn-signin" aria-label="Sign in with Google">
          <svg class="auth-google-icon" viewBox="0 0 24 24" width="18" height="18">
            <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 0 1-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z"/>
            <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
            <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
            <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
          </svg>
          <span>เข้าสู่ระบบ</span>
        </button>
      `;
      document.getElementById('btn-signin').addEventListener('click', handleSignIn);
    }
  }

  /* ===== Google Sign-In Callback ===== */
  function handleCredentialResponse(response) {
    const payload = parseJwt(response.credential);
    currentUser = {
      name: payload.name,
      email: payload.email,
      picture: payload.picture
    };
    localStorage.setItem('bunneis_user', JSON.stringify(currentUser));
    renderAuthUI();
  }

  /* ===== Parse JWT ===== */
  function parseJwt(token) {
    const base64Url = token.split('.')[1];
    const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
    const jsonPayload = decodeURIComponent(
      atob(base64).split('').map(c => '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2)).join('')
    );
    return JSON.parse(jsonPayload);
  }

  /* ===== Handle Sign In ===== */
  function handleSignIn() {
    if (CLIENT_ID && window.google) {
      // Real Google Sign-In
      google.accounts.id.prompt();
    } else {
      // Demo mode — show modal
      showSignInModal();
    }
  }

  /* ===== Demo Sign-In Modal ===== */
  function showSignInModal() {
    // Remove existing modal if any
    const existing = document.getElementById('signin-modal');
    if (existing) existing.remove();

    const modal = document.createElement('div');
    modal.id = 'signin-modal';
    modal.className = 'auth-modal-overlay';
    modal.innerHTML = `
      <div class="auth-modal">
        <button class="auth-modal-close" id="modal-close">&times;</button>
        <div class="auth-modal-header">
          <div class="auth-modal-logo">🐰</div>
          <h2 class="auth-modal-title">เข้าสู่ระบบ Bunneis</h2>
          <p class="auth-modal-subtitle">เข้าสู่ระบบด้วยบัญชี Google ของคุณ</p>
        </div>
        <div class="auth-modal-body">
          <button class="auth-google-btn" id="google-signin-real">
            <svg viewBox="0 0 24 24" width="20" height="20">
              <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 0 1-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z"/>
              <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
              <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
              <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
            </svg>
            เข้าสู่ระบบด้วย Google
          </button>
          <div class="auth-modal-divider"><span>หรือ</span></div>
          <div class="auth-demo-form">
            <input type="text" class="form-input" id="demo-name" placeholder="ชื่อของคุณ" value="Bunneis Fan">
            <input type="email" class="form-input" id="demo-email" placeholder="อีเมล" value="fan@bunneis.com">
            <button class="btn btn-primary" id="demo-signin" style="width:100%;">🐰 เข้าสู่ระบบ (Demo)</button>
          </div>
        </div>
        <p class="auth-modal-footer">เข้าสู่ระบบเพื่อรับสิทธิพิเศษสำหรับสมาชิก</p>
      </div>
    `;
    document.body.appendChild(modal);

    // Animate in
    requestAnimationFrame(() => modal.classList.add('show'));

    // Close modal
    document.getElementById('modal-close').addEventListener('click', closeModal);
    modal.addEventListener('click', (e) => { if (e.target === modal) closeModal(); });

    // Google real sign-in button
    document.getElementById('google-signin-real').addEventListener('click', () => {
      if (CLIENT_ID && window.google) {
        google.accounts.id.prompt();
        closeModal();
      } else {
        // If no client ID, fall through to demo
        alert('⚠️ กรุณาตั้งค่า Google Client ID ในไฟล์ js/auth.js\nใช้ Demo Mode แทนได้ด้านล่าง');
      }
    });

    // Demo sign-in
    document.getElementById('demo-signin').addEventListener('click', () => {
      const name = document.getElementById('demo-name').value || 'Bunneis Fan';
      const email = document.getElementById('demo-email').value || 'fan@bunneis.com';
      currentUser = {
        name: name,
        email: email,
        picture: `https://ui-avatars.com/api/?name=${encodeURIComponent(name)}&background=1B3A8C&color=fff&size=128&bold=true`
      };
      localStorage.setItem('bunneis_user', JSON.stringify(currentUser));
      closeModal();
      renderAuthUI();
    });
  }

  function closeModal() {
    const modal = document.getElementById('signin-modal');
    if (!modal) return;
    modal.classList.remove('show');
    setTimeout(() => modal.remove(), 300);
  }

  /* ===== Sign Out ===== */
  function signOut() {
    currentUser = null;
    localStorage.removeItem('bunneis_user');
    if (window.google && CLIENT_ID) {
      google.accounts.id.disableAutoSelect();
    }
    renderAuthUI();
  }

  /* ===== Init ===== */
  function init() {
    // Wait for header to load
    const checkHeader = setInterval(() => {
      if (document.getElementById('auth-container')) {
        clearInterval(checkHeader);
        renderAuthUI();
        // Init Google Identity Services if CLIENT_ID is set
        if (CLIENT_ID && window.google) {
          google.accounts.id.initialize({
            client_id: CLIENT_ID,
            callback: handleCredentialResponse
          });
        }
      }
    }, 100);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  // Expose for external use
  window.BunneisAuth = { signOut, getUser: () => currentUser };
})();
